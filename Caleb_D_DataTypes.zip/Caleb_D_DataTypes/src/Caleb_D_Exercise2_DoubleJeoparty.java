public class Caleb_D_Exercise2_DoubleJeoparty 
{
	  public static void main ( String[] args )
	  {
	    double value = 3.14E320;
	    //E320 causes it to be out of the range for double
	    System.out.println("A double: " +  value);
	  }
	}

