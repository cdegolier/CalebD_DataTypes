public class Caleb_D_Exercise1 {
	 public static void main ( String[] args )
	  {
	    int value = 350000;
	    System.out.println("An int: " +  value);
	    /*you need to convert it to an int for it to be able to compile 
	     since short cannot hold data that large*/
	  }
}
