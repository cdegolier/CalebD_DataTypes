
public class Caleb_D_Exercise2_ExperimentalExplosion
{
	  public static void main ( String[] args )
	  {
	    double value = 3200;
	    //changed value to infinity
	    System.out.println("e to the power value: " +  Math.exp( value ) );
	  }
}