
public class Caleb_D_Exercise3_CharacterAssassination
{
	  public static void main ( String[] args )
	  {
	    char ch = 'A' ;
	    System.out.println("A char: " +  ch );
	  }
}
/*
 Change the 'A' into 'Z' and compile and run.
 	Works as it it one character
Change the 'A' into 'AA' and try to compile the program.
	Does not work since 'AA' is more than one character
Change the 'A' into ' ' and compile and run the program.
	Works since ' ' is a character
Change the 'A' into '' and try to compile.
	Does not work there is no character
Change the 'A' into "A" and try to compile the program.
	Doesn't work - cannot convert string to char
 */